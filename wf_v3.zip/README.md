npm install @google/generative-ai
python -m http.server 8000
npm install dotenv
npm install axios
npm install unidecode

node setup.js D:\Downloads\outsrc\WORK_VER_2\WORK_VER_2
npm run dev